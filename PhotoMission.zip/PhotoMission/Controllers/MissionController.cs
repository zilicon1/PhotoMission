﻿using Microsoft.AspNetCore.Mvc;
using PhotoMission.Models;
using PhotoMission.Services;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Processing;
using System;
using System.IO;
using System.Threading.Tasks;

namespace PhotoMission.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MissionController : ControllerBase
    {
        private readonly IMissionService _missionService;

        // Constructor to inject the mission service
        public MissionController(IMissionService missionService)
        {
            _missionService = missionService;
        }

        // Endpoint to submit a photo for a specific mission
        [HttpPost("{missionId}/submit")]
        public async Task<IActionResult> SubmitPhoto(int missionId, [FromForm] MissionDTO missionDTO)
        {
            // Check if a photo was uploaded
            if (missionDTO.Photo == null || missionDTO.Photo.Length == 0)
            {
                return BadRequest("No photo uploaded.");
            }

            try
            {
                // Validate the file type (only image files are allowed)
                if (!missionDTO.Photo.ContentType.StartsWith("image/"))
                {
                    return BadRequest("Only image files are allowed.");
                }

                // Ensure the uploads directory exists
                var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "uploads");
                if (!Directory.Exists(uploadDirectory))
                {
                    Directory.CreateDirectory(uploadDirectory);
                }

                // Generate a unique file name based on GUID to avoid name collisions
                var fileName = $"{Guid.NewGuid()}_{missionDTO.Photo.FileName}";
                var filePath = Path.Combine(uploadDirectory, fileName);

                // Load and resize the image to ensure it's under 100 KB
                using (var stream = missionDTO.Photo.OpenReadStream())
                {
                    using (var image = await Image.LoadAsync(stream))
                    {
                        // Resize the image while maintaining aspect ratio
                        const int maxWidth = 500; // Resize to smaller dimensions to reduce file size
                        const int maxHeight = 500;

                        image.Mutate(x => x.Resize(maxWidth, maxHeight));

                        // Set an initial quality value for the JPEG encoder
                        var quality = 80; // Start with a higher quality to reduce file size slowly

                        // Try to save the image with reduced quality if the size exceeds 100 KB
                        while (true)
                        {
                            var encoder = new JpegEncoder { Quality = quality };

                            // Save the image to a memory stream
                            using (var memoryStream = new MemoryStream())
                            {
                                await image.SaveAsync(memoryStream, encoder);

                                // Check the size of the image in the memory stream
                                if (memoryStream.Length <= 100 * 1024) // 100 KB
                                {
                                    // If the image is under 100 KB, save it to the file system
                                    await using (var outputStream = new FileStream(filePath, FileMode.Create))
                                    {
                                        memoryStream.Seek(0, SeekOrigin.Begin);
                                        await memoryStream.CopyToAsync(outputStream);
                                    }
                                    break;
                                }
                                else
                                {
                                    // If the image is too large, decrease the quality and try again
                                    quality -= 5; // Reduce quality by 5 each time
                                    if (quality <= 50) // Stop when the quality reaches 50
                                    {
                                        // At the lowest acceptable quality, save it anyway
                                        await using (var outputStream = new FileStream(filePath, FileMode.Create))
                                        {
                                            memoryStream.Seek(0, SeekOrigin.Begin);
                                            await memoryStream.CopyToAsync(outputStream);
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }

                // Check if the mission exists in the database
                var mission = await _missionService.GetMissionByIdAsync(missionId);
                if (mission == null)
                {
                    return BadRequest("Mission not found.");
                }

                // Create a mission submission object to save in the database
                var submission = new MissionSubmission
                {
                    MissionId = missionId,
                    Description = missionDTO.Description,
                    PhotoPath = filePath,
                    SubmissionDate = DateTime.UtcNow,
                    IsValid = false // Set the validation status to false initially
                };

                // Log submission details before saving (optional debugging)
                Console.WriteLine($"MissionId: {submission.MissionId}, Description: {submission.Description}, PhotoPath: {submission.PhotoPath}");

                // Save the submission to the database using the service
                await _missionService.SaveSubmissionAsync(submission);

                // Return a success response with the file path
                return Ok(new { Message = "Photo submitted successfully.", FilePath = filePath });
            }
            catch (Exception ex)
            {
                // Detailed error logging
                var errorMessage = $"An error occurred: {ex.Message}";

                // Check for inner exception details
                if (ex.InnerException != null)
                {
                    errorMessage += $". Inner Exception: {ex.InnerException.Message}";
                }

                // Log the error (can be logged to a file or a logging service)
                Console.WriteLine(errorMessage);

                // Return the error message as part of the response
                return BadRequest(errorMessage);
            }
        }
    }
}
