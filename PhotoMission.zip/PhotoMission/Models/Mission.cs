﻿using Microsoft.AspNetCore.Mvc;

namespace PhotoMission.Models
{
    public class Mission
    {
        public int Id { get; set; } // Primary key
        public string Name { get; set; } // Mission name
        public string Description { get; set; } // Mission description
        public DateTime CreatedDate { get; set; } // When the mission was created
    }
}
