﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace PhotoMission.Models
{
    public class MissionDTO
    {
        [Required]
        public IFormFile Photo { get; set; } // The uploaded photo

        public string Description { get; set; } // The description for the submission
    }
}
