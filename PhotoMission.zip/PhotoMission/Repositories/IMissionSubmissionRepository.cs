﻿using PhotoMission.Models;
using System.Threading.Tasks;

namespace PhotoMission.Repositories
{
    public interface IMissionSubmissionRepository
    {
        Task SaveAsync(MissionSubmission submission);
    }
}
