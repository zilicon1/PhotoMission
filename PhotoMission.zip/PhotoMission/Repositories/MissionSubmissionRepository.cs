﻿using PhotoMission.Data;
using PhotoMission.Models;
using System.Threading.Tasks;

namespace PhotoMission.Repositories
{
    public class MissionSubmissionRepository : IMissionSubmissionRepository
    {
        private readonly ApplicationDbContext _context;

        public MissionSubmissionRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task SaveAsync(MissionSubmission submission)
        {
            _context.MissionSubmissions.Add(submission);
            await _context.SaveChangesAsync();
        }
        public async Task CreateSubmissionAsync(MissionSubmission submission)
        {
            _context.MissionSubmissions.Add(submission);
            await _context.SaveChangesAsync();
        }

    }
}
