﻿using PhotoMission.Models;
using System.Threading.Tasks;

namespace PhotoMission.Services
{
    public interface IMissionService
    {
        Task SaveSubmissionAsync(MissionSubmission submission);
        Task<Mission> GetMissionByIdAsync(int missionId);
    }
}