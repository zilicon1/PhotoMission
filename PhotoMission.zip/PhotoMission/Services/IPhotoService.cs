﻿using Microsoft.AspNetCore.Mvc;

namespace PhotoMission.Services
{
    public class IPhotoService : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
